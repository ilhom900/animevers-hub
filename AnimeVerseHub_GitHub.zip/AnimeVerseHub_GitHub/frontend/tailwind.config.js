export default {
  content: ["./index.html","./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        tpn: { dark: '#0B0E11', red: '#C41E3A', gold: '#D4AF37' }
      }
    },
  },
  plugins: [],
}