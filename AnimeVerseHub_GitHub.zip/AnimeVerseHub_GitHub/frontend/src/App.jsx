import { useEffect, useState } from 'react'

export default function App() {
  const [data, setData] = useState(null)
  
  useEffect(() => {
    fetch('/api/anime/tpn').then(r => r.json()).then(setData)
  }, [])

  if (!data) return <div className="p-8 text-center">Загрузка...</div>

  return (
    <div className="min-h-screen bg-tpn-dark">
      <nav className="bg-black/50 border-b border-tpn-red/30 px-6 py-4">
        <div className="max-w-6xl mx-auto text-2xl font-bold">
          <span className="text-tpn-red">Anime</span>
          <span className="text-tpn-gold">Verse</span>
          <span className="text-white"> Hub</span>
        </div>
      </nav>
      <div className="max-w-6xl mx-auto px-6 py-12">
        <h1 className="text-5xl font-bold mb-4 text-center">
          <span className="text-tpn-red">The Promised</span> Neverland
        </h1>
        <p className="text-xl text-gray-300 max-w-2xl mx-auto text-center mb-16">{data.description}</p>
        <div className="grid md:grid-cols-3 gap-8">
          {data.chars.map(c => (
            <div key={c.id} className="bg-black/40 border border-tpn-red/20 rounded-lg p-6">
              <h3 className="text-2xl font-bold text-tpn-gold mb-2">{c.name}</h3>
              <p className="text-sm text-gray-500 mb-2">№{c.id}</p>
              <p className="text-gray-300">{c.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}