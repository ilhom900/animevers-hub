# AnimeVerse Hub

**Деплой на Render.com с телефона:**

1. Зайди на render.com через браузер, войди через GitHub
2. New + → Web Service → Connect a repository → выбери animeverse-hub
3. Build Command: `npm run build`
4. Start Command: `npm start`
5. Create Web Service

Готово. Сайт будет на https://animeverse-hub.onrender.com

**Локально на телефоне:** пока нельзя, но код в GitHub сохранится.
