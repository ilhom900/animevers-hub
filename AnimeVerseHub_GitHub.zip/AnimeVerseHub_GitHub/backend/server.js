import express from 'express'
import cors from 'cors'
import path from 'path'
import { fileURLToPath } from 'url'

const app = express()
app.use(cors())
app.use(express.json())

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const frontendPath = path.join(__dirname, '../frontend/dist')
app.use(express.static(frontendPath))

app.get('/api/health', (req, res) => {
  res.json({ status: 'AnimeVerse Hub работает!' })
})

app.get('/api/anime/tpn', (req, res) => {
  res.json({
    title: 'The Promised Neverland',
    description: 'Grace Field House — это приют или ферма? Эмма, Норман и Рэй раскроют страшную правду.',
    chars: [
      { name: 'Эмма', id: '63194', desc: 'Оптимистка. Не бросит никого.' },
      { name: 'Норман', id: '22194', desc: 'Гений-стратег. Готов пожертвовать собой.' },
      { name: 'Рэй', id: '81194', desc: 'Циник с фотографической памятью.' }
    ]
  })
})

app.get('*', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'))
})

const port = process.env.PORT || 3000
app.listen(port, () => console.log(`Server on ${port}`))
